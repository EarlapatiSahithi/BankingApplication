import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';

import { ErrorpageComponent } from './errorpage/errorpage.component';

import { LoanrequestComponent } from './loanrequest/loanrequest.component';
import { BankguardGuard } from './bankguard.guard';



const routes: Routes = [
  
  {path:'login', component:LoginComponent},
  {path:'error',component:ErrorpageComponent},
  {path:'loanrequest',component:LoanrequestComponent, canActivate:[BankguardGuard],data:{role:'customer'}}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
