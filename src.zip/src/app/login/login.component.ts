import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from '../storage.service';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userid:string;
  pwd:string;
  msg:string;
  constructor(private router:Router,private storageservice:StorageService,private loanservice :LoanService) 
  {

   }
 
  ngOnInit(): void {
  }
  doLogin(){
this.loanservice.doLogin(this.userid,this.pwd).subscribe(data=>{
  this.storageservice.setItem("tokenId",data);
  this.msg=undefined;
      this.router.navigateByUrl("/");
},error=>{this.msg=error.error.message});

  }

}
