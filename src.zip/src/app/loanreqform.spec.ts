import { Loanreqform } from './loanreqform';

describe('Loanreqform', () => {
  it('should create an instance', () => {
    expect(new Loanreqform()).toBeTruthy();
  });
});
