export class Loanreqform {
   loanRequestId:string;
    loanAmount:string;
    loanType:string;
    loanTenure:number;
    reqStatus:string;
    dateOfRequest:string;
    annualIncome:string;
    customerId:string;
}
