import { Acctransaction } from './acctransaction';

describe('Acctransaction', () => {
  it('should create an instance', () => {
    expect(new Acctransaction()).toBeTruthy();
  });
});
