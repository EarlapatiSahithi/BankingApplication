import { SearchbycustidPipe } from './searchbycustid.pipe';

describe('SearchbycustidPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchbycustidPipe();
    expect(pipe).toBeTruthy();
  });
});
