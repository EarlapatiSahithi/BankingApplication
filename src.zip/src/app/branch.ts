export class Branch {
    branchId:string;
    branchName:string;
    branchIFSC:string;
    branchAddress:string;
}
