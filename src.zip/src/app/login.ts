export class Login {
    userid:string;
    pwd:string;
    role:string;

}
